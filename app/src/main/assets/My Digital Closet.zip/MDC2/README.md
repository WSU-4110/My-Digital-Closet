# My-Digital-Closet
## Wardrobe cataloguing app
### Software Used
- Android Studio
* Firebase
+ Figma
- Jira
